import TodoItem from '@/models/TodoItem';
import axiosBase from 'axios';

const axios = axiosBase.create({
    baseURL: 'http://localhost:9999',
    headers: {
        'Content-Type': 'application/json',
    },
    responseType: 'json',
});

class TodoService {
    async getAll(): Promise<TodoItem[]> {
        const response = await axios.get('/');
        return response.data as TodoItem[];
    }
}

export default new TodoService();
