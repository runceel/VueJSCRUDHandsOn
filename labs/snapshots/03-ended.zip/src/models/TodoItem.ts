export default interface TodoItem {
    id: number;
    text: string;
    done: boolean;
}
