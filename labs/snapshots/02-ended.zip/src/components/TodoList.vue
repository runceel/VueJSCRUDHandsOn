<template>
    <div id="todo-list">
        <h1>TODO リスト</h1>
        <ol>
            <li v-for="todo in todos" v-bind:key="todo.id">
                <input type="checkbox" :checked="todo.done" disabled="disabled" />
                {{ todo.text }}
            </li>
        </ol>
    </div>
</template>

<script lang="ts">
import Vue from 'vue';
import TodoItem from '@/models/TodoItem';
import todoService from '@/services/TodoService';

declare interface TodoListData {
    todos: TodoItem[];
}

export default Vue.extend({
    data() {
        return {
            todos: [],
        } as TodoListData;
    },
    async created() {
        this.todos = await todoService.getAll();
    }
})
</script>

<style>
li {
    list-style-type: none;
}
</style>
