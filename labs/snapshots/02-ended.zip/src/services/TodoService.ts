import TodoItem from '@/models/TodoItem';

const todos = [
    { id: 1, text: 'sample todo 1', done: false },
    { id: 2, text: 'sample todo 2', done: true },
    { id: 3, text: 'sample todo 3', done: false },
] as TodoItem[];

class TodoService {
    async getAll(): Promise<TodoItem[]> {
        return Promise.resolve(todos);
    }
}

export default new TodoService();
